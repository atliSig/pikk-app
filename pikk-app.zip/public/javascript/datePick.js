/**
 * Created by atli on 23.11.2016.
 */
$( function() {
    $( ".pick-date" ).datepicker();
});