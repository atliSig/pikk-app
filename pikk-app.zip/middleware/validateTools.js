/**
 * Created by atli on 5.11.2016.
 */


//This is not used currently
exports.pikkForm = function(req,res,next){
    //data contains pikk params from a single user
    var data;
    req.pikkParam = data;
    next();
};